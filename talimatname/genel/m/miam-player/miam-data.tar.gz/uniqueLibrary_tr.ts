<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>TableView</name>
    <message>
        <location filename="../tableview.cpp" line="112"/>
        <source>No matching results were found</source>
        <translation type="unfinished">Eşleşen sonuç bulunamadı</translation>
    </message>
</context>
<context>
    <name>UniqueLibrary</name>
    <message>
        <location filename="../uniquelibrary.cpp" line="208"/>
        <source>Your library is updating...</source>
        <translation type="unfinished">Kütüphaneniz güncelliyor ...</translation>
    </message>
</context>
<context>
    <name>UniqueLibraryItemDelegate</name>
    <message>
        <location filename="../uniquelibraryitemdelegate.cpp" line="87"/>
        <source>(no title)</source>
        <translation type="unfinished">(başlıksız)</translation>
    </message>
    <message>
        <location filename="../uniquelibraryitemdelegate.cpp" line="139"/>
        <source>Disc</source>
        <translation type="unfinished">Disk</translation>
    </message>
    <message>
        <location filename="../uniquelibraryitemdelegate.cpp" line="189"/>
        <source>(empty)</source>
        <translation type="unfinished">(boş)</translation>
    </message>
</context>
<context>
    <name>uniqueLibrary</name>
    <message>
        <location filename="../uniquelibrary.ui" line="263"/>
        <source>Search...</source>
        <translation type="unfinished">Arama...</translation>
    </message>
</context>
</TS>
