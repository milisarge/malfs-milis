<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="en_US">
<context>
    <name>LibraryHeader</name>
    <message>
        <source>Album</source>
        <translation type="unfinished">Albüm</translation>
    </message>
    <message>
        <source>Artist – Album</source>
        <translation type="unfinished">Sanatçı – Albüm</translation>
    </message>
    <message>
        <source>Year</source>
        <translation type="unfinished">Yıl</translation>
    </message>
    <message>
        <source>Artist \ Album</source>
        <translation type="unfinished">Sanatçı \ Albüm</translation>
    </message>
</context>
<context>
    <name>LibraryItemDelegate</name>
    <message>
        <source>(empty)</source>
        <translation type="unfinished">(boş)</translation>
    </message>
</context>
<context>
    <name>LibraryItemModel</name>
    <message>
        <source>  Artists \ Albums</source>
        <translation type="unfinished">  Sanatçı \ Albümler</translation>
    </message>
    <message>
        <source>  Albums</source>
        <translation type="unfinished">  Albümler</translation>
    </message>
    <message>
        <source>  Artists – Albums</source>
        <translation type="unfinished">  Sanatçı – Albümler</translation>
    </message>
    <message>
        <source>  Years</source>
        <translation type="unfinished">  Yıl</translation>
    </message>
</context>
<context>
    <name>LibraryOrderDialog</name>
    <message>
        <source>Select how to display your library</source>
        <translation type="unfinished">Kitaplığınızı nasıl görüntüleyeceğinizi seçin</translation>
    </message>
    <message>
        <source>Artists \ Albums</source>
        <translation type="unfinished">Sanatçı \ Albümler</translation>
    </message>
    <message>
        <source>Artist</source>
        <translation type="unfinished">Sanatçı</translation>
    </message>
    <message>
        <source>Album</source>
        <translation type="unfinished">Albüm</translation>
    </message>
    <message>
        <source>Albums</source>
        <translation type="unfinished">Albümler</translation>
    </message>
    <message>
        <source>Artists – Albums</source>
        <translation type="unfinished">Sanatçı – Albümler</translation>
    </message>
    <message>
        <source>Artist – Album</source>
        <translation type="unfinished">Sanatçı – Albüm</translation>
    </message>
    <message>
        <source>01. track #1</source>
        <translation type="unfinished">01. parça #1</translation>
    </message>
    <message>
        <source>02. track #2</source>
        <translation type="unfinished">02. parça #2</translation>
    </message>
    <message>
        <source>Years</source>
        <translation type="unfinished">Yıl</translation>
    </message>
</context>
<context>
    <name>LibraryTreeView</name>
    <message>
        <source>Send to the current playlist</source>
        <translation type="unfinished">Geçerli çalma listesine gönder</translation>
    </message>
    <message>
        <source>Send to the tag editor</source>
        <translation type="unfinished">Etiket düzenleyicisine gönder</translation>
    </message>
    <message>
        <source>No matching results were found</source>
        <translation type="unfinished">Eşleşen sonuç bulunamadı</translation>
    </message>
</context>
<context>
    <name>MiamItemDelegate</name>
    <message>
        <source>(empty)</source>
        <translation type="unfinished">(boş)</translation>
    </message>
</context>
<context>
    <name>MiamItemModel</name>
    <message>
        <source>Various</source>
        <translation type="unfinished">Çeşitli</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Unknown</source>
        <translation type="unfinished">Bilinmeyen</translation>
    </message>
</context>
</TS>
